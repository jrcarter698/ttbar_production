from . import algebra, code_writer, decomposition, expansion, misc, polytope, loop_integral, subtraction, integral_interface
from .code_writer import make_package
from .metadata import __authors__, __version__, git_id
