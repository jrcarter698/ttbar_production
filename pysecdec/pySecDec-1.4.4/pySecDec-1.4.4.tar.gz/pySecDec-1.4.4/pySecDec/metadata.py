version = __version__ = '1.4.4'
authors = __authors__ = 'Sophia Borowka, Gudrun Heinrich, Stephan Jahn, Stephen Jones, Matthias Kerner, Johannes Schlenk, Tom Zirke'
git_id = '6c3b20e8b63368c4ef7fa0d7e5d410d88ecde994'
