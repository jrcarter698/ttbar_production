#include <vector>

#include "%(name)s.hpp"

namespace %(name)s
{
    const std::vector<std::vector<real_t>> pole_structures = {%(pole_structures_initializer)s};
};
